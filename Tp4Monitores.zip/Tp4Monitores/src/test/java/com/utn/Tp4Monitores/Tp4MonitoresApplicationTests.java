package com.utn.Tp4Monitores;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class Tp4MonitoresApplicationTests {

	@Test
	public void contextLoads() {
	}

}
